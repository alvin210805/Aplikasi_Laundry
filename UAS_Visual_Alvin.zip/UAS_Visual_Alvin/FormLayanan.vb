﻿Imports System.Data.SqlClient
Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Public Class FormLayanan
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim layananArray(100) As String ' Materi: Array

    Sub koneksi()
        conn = New MySqlConnection("server=localhost;userid=root;password=;database=db_laundry")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    Sub tampilLayanan()
        koneksi()
        da = New MySqlDataAdapter("SELECT * FROM layanan", conn)
        ds = New DataSet
        da.Fill(ds, "layanan")
        DataGridView1.DataSource = ds.Tables("layanan")
    End Sub

    Sub clearForm()
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub FormLayanan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Nama Layanan"
        Label2.Text = "Harga per Kg"
        Button1.Text = "Simpan"
        Button2.Text = "Hapus"

        tampilLayanan()
        isiArrayLayanan()
    End Sub

    ' Materi: Looping + Array
    Sub isiArrayLayanan()
        koneksi()
        Dim cmdArray As New MySqlCommand("SELECT nama_layanan FROM layanan", conn)
        Dim rd As MySqlDataReader = cmdArray.ExecuteReader()
        Dim i As Integer = 0

        While rd.Read()
            layananArray(i) = rd("nama_layanan").ToString()
            i += 1
        End While
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("Data tidak boleh kosong!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        koneksi()
        cmd = New MySqlCommand("INSERT INTO layanan (nama_layanan, harga_per_kg) VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "')", conn)
        cmd.ExecuteNonQuery()
        MsgBox("Layanan berhasil ditambahkan!", MsgBoxStyle.Information)

        tampilLayanan()
        clearForm()
        isiArrayLayanan()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.CurrentRow Is Nothing Then
            MsgBox("Pilih data yang ingin dihapus.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim id As String = DataGridView1.CurrentRow.Cells(0).Value.ToString()
        koneksi()
        cmd = New MySqlCommand("DELETE FROM layanan WHERE id_layanan='" & id & "'", conn)
        cmd.ExecuteNonQuery()

        MsgBox("Layanan berhasil dihapus.", MsgBoxStyle.Information)
        tampilLayanan()
        clearForm()
        isiArrayLayanan()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
