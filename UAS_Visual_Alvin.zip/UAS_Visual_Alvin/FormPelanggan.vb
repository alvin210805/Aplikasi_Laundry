﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Public Class FormPelanggan
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim da As MySqlDataAdapter
    Dim ds As DataSet
    Dim id_pelanggan As String

    ' Prosedur koneksi
    Sub koneksi()
        conn = New MySqlConnection("server=localhost;userid=root;password=;database=db_laundry")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    ' Prosedur tampil data ke grid
    Sub tampilData()
        koneksi()
        da = New MySqlDataAdapter("SELECT * FROM pelanggan", conn)
        ds = New DataSet
        da.Fill(ds, "pelanggan")
        DataGridView1.DataSource = ds.Tables("pelanggan")
    End Sub

    ' Prosedur clear form
    Sub clearForm()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        id_pelanggan = ""
    End Sub

    Private Sub FormPelanggan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Label dan tombol
        Label1.Text = "Nama Pelanggan"
        Label2.Text = "Alamat"
        Label3.Text = "No HP"
        Button1.Text = "Simpan"
        Button2.Text = "Update"
        Button3.Text = "Hapus"

        tampilData()
    End Sub

    ' Tombol Simpan
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("Semua data harus diisi!", MsgBoxStyle.Critical)
            Exit Sub
        End If

        koneksi()
        cmd = New MySqlCommand("INSERT INTO pelanggan (nama_pelanggan, alamat, no_hp) VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "')", conn)
        cmd.ExecuteNonQuery()
        MsgBox("Data berhasil disimpan.", MsgBoxStyle.Information)

        tampilData()
        clearForm()
    End Sub

    ' Klik baris di DataGridView
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            Dim row As Integer = e.RowIndex
            id_pelanggan = DataGridView1.Rows(row).Cells(0).Value.ToString()
            TextBox1.Text = DataGridView1.Rows(row).Cells(1).Value.ToString()
            TextBox2.Text = DataGridView1.Rows(row).Cells(2).Value.ToString()
            TextBox3.Text = DataGridView1.Rows(row).Cells(3).Value.ToString()
        Catch ex As Exception
        End Try
    End Sub

    ' Tombol Update
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If id_pelanggan = "" Then
            MsgBox("Pilih data yang akan diupdate!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        koneksi()
        cmd = New MySqlCommand("UPDATE pelanggan SET nama_pelanggan='" & TextBox1.Text & "', alamat='" & TextBox2.Text & "', no_hp='" & TextBox3.Text & "' WHERE id_pelanggan='" & id_pelanggan & "'", conn)
        cmd.ExecuteNonQuery()
        MsgBox("Data berhasil diupdate.", MsgBoxStyle.Information)

        tampilData()
        clearForm()
    End Sub

    ' Tombol Hapus
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If id_pelanggan = "" Then
            MsgBox("Pilih data yang akan dihapus!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Yakin ingin menghapus data ini?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            koneksi()
            cmd = New MySqlCommand("DELETE FROM pelanggan WHERE id_pelanggan='" & id_pelanggan & "'", conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data berhasil dihapus.", MsgBoxStyle.Information)

            tampilData()
            clearForm()
        End If
    End Sub
End Class
