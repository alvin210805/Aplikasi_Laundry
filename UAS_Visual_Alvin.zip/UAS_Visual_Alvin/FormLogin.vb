﻿Imports System.Data.SqlClient
Imports System.Reflection.Emit
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient

Public Class FormLogin
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim rd As MySqlDataReader

    Sub koneksi()
        conn = New MySqlConnection("server=localhost;userid=root;password=;database=db_laundry")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Username"
        Label2.Text = "Password"
        Button1.Text = "Login"
        TextBox2.UseSystemPasswordChar = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        koneksi()
        Dim user As String = TextBox1.Text
        Dim pass As String = TextBox2.Text

        cmd = New MySqlCommand("SELECT * FROM users WHERE username='" & user & "' AND password='" & pass & "'", conn)
        rd = cmd.ExecuteReader
        If rd.HasRows Then
            rd.Read()
            MsgBox("Login Berhasil", MsgBoxStyle.Information, "Sukses")

            FormMainMenu.Show()
            FormMainMenu.Label1.Text = "Login sebagai: " & rd("username") & " [" & rd("level") & "]"
            Me.Hide()
        Else
            MsgBox("Login Gagal! Username atau Password salah", MsgBoxStyle.Critical, "Gagal")
        End If
    End Sub
End Class
