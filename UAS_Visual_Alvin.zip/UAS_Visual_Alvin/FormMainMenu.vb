﻿Public Class FormMainMenu
    Private Sub FormMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set form sebagai MDI Parent
        Me.IsMdiContainer = True
        Me.Text = "Toko Laundry - Menu Utama"
        Me.WindowState = FormWindowState.Maximized

        ' Ubah label info login
        Label1.Text = "Selamat datang, [user]"
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10, FontStyle.Bold)
        Label1.ForeColor = Color.DarkBlue
        Label1.Location = New Point(20, 30)

        ' Inisialisasi jam
        Timer1.Interval = 1000
        Timer1.Start()

        ' Atur MenuStrip
        MenuStrip1.Items.Clear()

        ' MASTER DATA
        Dim menuMaster As New ToolStripMenuItem("Master Data")
        Dim menuPelanggan As New ToolStripMenuItem("Data Pelanggan")
        Dim menuLayanan As New ToolStripMenuItem("Data Layanan")

        AddHandler menuPelanggan.Click, AddressOf bukaFormPelanggan
        AddHandler menuLayanan.Click, AddressOf bukaFormLayanan

        menuMaster.DropDownItems.Add(menuPelanggan)
        menuMaster.DropDownItems.Add(menuLayanan)

        ' TRANSAKSI
        Dim menuTransaksi As New ToolStripMenuItem("Transaksi")
        Dim menuInputTransaksi As New ToolStripMenuItem("Transaksi Laundry")
        AddHandler menuInputTransaksi.Click, AddressOf bukaFormTransaksi
        menuTransaksi.DropDownItems.Add(menuInputTransaksi)

        ' LAPORAN
        Dim menuLaporan As New ToolStripMenuItem("Laporan")
        Dim menuLaporanTransaksi As New ToolStripMenuItem("Laporan Transaksi")
        AddHandler menuLaporanTransaksi.Click, AddressOf bukaFormLaporan
        menuLaporan.DropDownItems.Add(menuLaporanTransaksi)

        ' LOGOUT
        Dim menuLogout As New ToolStripMenuItem("Logout")
        AddHandler menuLogout.Click, AddressOf logoutAplikasi

        ' Tambahkan semua menu
        MenuStrip1.Items.Add(menuMaster)
        MenuStrip1.Items.Add(menuTransaksi)
        MenuStrip1.Items.Add(menuLaporan)
        MenuStrip1.Items.Add(menuLogout)
    End Sub

    ' Tampilkan jam
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Text = "Toko Laundry - " & TimeOfDay.ToString("HH:mm:ss")
    End Sub

    ' Aksi buka form pelanggan
    Private Sub bukaFormPelanggan()
        FormPelanggan.MdiParent = Me
        FormPelanggan.Show()
        FormPelanggan.Focus()
    End Sub

    ' Aksi buka form layanan
    Private Sub bukaFormLayanan()
        FormLayanan.MdiParent = Me
        FormLayanan.Show()
        FormLayanan.Focus()
    End Sub

    ' Aksi buka form transaksi
    Private Sub bukaFormTransaksi()
        FormTransaksi.MdiParent = Me
        FormTransaksi.Show()
        FormTransaksi.Focus()
    End Sub

    ' Aksi buka form laporan
    Private Sub bukaFormLaporan()
        FormLaporan.MdiParent = Me
        FormLaporan.Show()
        FormLaporan.Focus()
    End Sub

    ' Aksi logout
    Private Sub logoutAplikasi()
        If MsgBox("Yakin ingin logout?", MsgBoxStyle.YesNo, "Konfirmasi") = MsgBoxResult.Yes Then
            Me.Hide()
            FormLogin.Show()
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
