﻿Imports MySql.Data.MySqlClient

Public Class FormTransaksi
    ' Deklarasi koneksi & perintah
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim rd As MySqlDataReader

    ' Koneksi ke database
    Sub Koneksi()
        conn = New MySqlConnection("server=localhost;userid=root;password=;database=db_laundry")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    ' Prosedur tampilkan data manual (atau nanti dari DB)
    Sub TampilTransaksi()
        ' Atur ListView
        ListView1.Items.Clear()
        ListView1.Columns.Clear()
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True

        ' Tambahkan kolom
        ListView1.Columns.Add("ID", 50)
        ListView1.Columns.Add("Nama", 100)
        ListView1.Columns.Add("Tanggal", 100)
        ListView1.Columns.Add("Total", 100)
        ListView1.Columns.Add("Status", 100)

        ' Tambahkan data manual 
        Dim item1 As New ListViewItem("1")
        item1.SubItems.Add("Maya")
        item1.SubItems.Add("09/07/2025")
        item1.SubItems.Add("15000")
        item1.SubItems.Add("Proses")
        ListView1.Items.Add(item1)

        Dim item2 As New ListViewItem("2")
        item2.SubItems.Add("Limah")
        item2.SubItems.Add("08/07/2025")
        item2.SubItems.Add("20000")
        item2.SubItems.Add("Proses")
        ListView1.Items.Add(item2)

        Dim item3 As New ListViewItem("3")
        item3.SubItems.Add("Ruanah")
        item3.SubItems.Add("05/07/2025")
        item3.SubItems.Add("18000")
        item3.SubItems.Add("Selesai")
        ListView1.Items.Add(item3)

        Dim item4 As New ListViewItem("4")
        item4.SubItems.Add("Intan")
        item4.SubItems.Add("01/07/2025")
        item4.SubItems.Add("34000")
        item4.SubItems.Add("Selesai")
        ListView1.Items.Add(item4)
    End Sub

    ' Saat form dimuat
    Private Sub FormTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Laporan Transaksi Laundry"
        TampilTransaksi()
    End Sub

    ' Tombol Lihat Detail
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ListView1.SelectedItems.Count = 0 Then
            MsgBox("Pilih transaksi dulu!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim selected As ListViewItem = ListView1.SelectedItems(0)
        Dim detail As String = "ID Transaksi: " & selected.SubItems(0).Text & vbCrLf &
                               "Pelanggan: " & selected.SubItems(1).Text & vbCrLf &
                               "Tanggal: " & selected.SubItems(2).Text & vbCrLf &
                               "Total: " & selected.SubItems(3).Text & vbCrLf &
                               "Status: " & selected.SubItems(4).Text
        MsgBox(detail, MsgBoxStyle.Information, "Detail Transaksi")
    End Sub

    ' Tombol Cetak
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If ListView1.SelectedItems.Count = 0 Then
            MsgBox("Pilih data dulu untuk dicetak!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim selected As ListViewItem = ListView1.SelectedItems(0)
        MsgBox("Mencetak transaksi ID: " & selected.SubItems(0).Text, MsgBoxStyle.Information)
    End Sub
End Class
