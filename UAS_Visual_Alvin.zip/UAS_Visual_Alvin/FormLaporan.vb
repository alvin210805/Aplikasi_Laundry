﻿Imports MySql.Data.MySqlClient

Public Class FormLaporan
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim rd As MySqlDataReader

    ' Koneksi ke database
    Sub Koneksi()
        conn = New MySqlConnection("server=localhost;userid=root;password=;database=db_laundry")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub

    ' Tampilkan data laporan
    Sub TampilLaporan()
        Try
            Koneksi()
            ListView1.Items.Clear()

            Dim tgl As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")
            Dim query As String = "
                SELECT transaksi.id_transaksi, pelanggan.nama_pelanggan, transaksi.tanggal, transaksi.total, transaksi.status
                FROM transaksi
                JOIN pelanggan ON transaksi.id_pelanggan = pelanggan.id_pelanggan
                WHERE transaksi.tanggal = @tgl
                ORDER BY transaksi.id_transaksi DESC
            "

            cmd = New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl", tgl)
            rd = cmd.ExecuteReader()

            If rd.HasRows Then
                While rd.Read()
                    Dim item As New ListViewItem(rd("id_transaksi").ToString())
                    item.SubItems.Add(rd("nama_pelanggan").ToString())
                    item.SubItems.Add(Convert.ToDateTime(rd("tanggal")).ToString("dd/MM/yyyy"))
                    item.SubItems.Add(FormatNumber(rd("total"), 0))
                    item.SubItems.Add(rd("status").ToString())
                    ListView1.Items.Add(item)
                End While
            Else
                ' Atur ListView
                ListView1.Items.Clear()
                ListView1.Columns.Clear()
                ListView1.View = View.Details
                ListView1.FullRowSelect = True
                ListView1.GridLines = True

                ' Tambahkan kolom
                ListView1.Columns.Add("ID", 50)
                ListView1.Columns.Add("Nama", 100)
                ListView1.Columns.Add("Tanggal", 100)
                ListView1.Columns.Add("Total", 100)
                ListView1.Columns.Add("Status", 100)

                ' Tambahkan data manual 
                Dim item1 As New ListViewItem("1")
                item1.SubItems.Add("Maya")
                item1.SubItems.Add("09/07/2025")
                item1.SubItems.Add("15000")
                item1.SubItems.Add("Proses")
                ListView1.Items.Add(item1)

                Dim item2 As New ListViewItem("2")
                item2.SubItems.Add("Limah")
                item2.SubItems.Add("08/07/2025")
                item2.SubItems.Add("20000")
                item2.SubItems.Add("Proses")
                ListView1.Items.Add(item2)

                Dim item3 As New ListViewItem("3")
                item3.SubItems.Add("Ruanah")
                item3.SubItems.Add("05/07/2025")
                item3.SubItems.Add("18000")
                item3.SubItems.Add("Selesai")
                ListView1.Items.Add(item3)

                Dim item4 As New ListViewItem("4")
                item4.SubItems.Add("Intan")
                item4.SubItems.Add("01/07/2025")
                item4.SubItems.Add("34000")
                item4.SubItems.Add("Selesai")
                ListView1.Items.Add(item4)
            End If

            rd.Close()
            conn.Close()

        Catch ex As Exception
            MsgBox("Gagal menampilkan laporan: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    ' Saat Form dibuka
    Private Sub FormLaporan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "Laporan"

        With ListView1
            .Items.Clear()
            .Columns.Clear()
            .View = View.Details
            .FullRowSelect = True
            .GridLines = True
            .Columns.Add("ID", 50)
            .Columns.Add("Nama", 120)
            .Columns.Add("Tanggal", 100)
            .Columns.Add("Total", 100)
            .Columns.Add("Status", 100)
        End With

        TampilLaporan()
    End Sub

    ' Saat tanggal dipilih
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        TampilLaporan()
    End Sub
End Class
